<!DOCTYPE html>
<html>
<head>
    <title>Internal and External JavaScript</title>

    <!-- Internal JavaScript: alert() displays a popup message -->
    <script>
        function internalMessage() {
            alert("This is Internal JavaScript");
        }
    </script>
</head>

<body>

    <h1>JavaScript Embedding Example</h1>

    <button onclick="internalMessage()">
        Internal JavaScript
    </button>

    <br><br>

    <button onclick="externalMessage()">
        External JavaScript
    </button>

    <!-- External JavaScript -->
    <script src="script.js"></script>

</body>
</html>